"""
-------------------------------------------------------
T01
-------------------------------------------------------
Author:  Mila Cvetanovska
ID:      210311400
Email:   cvet1400@mylaurier.ca
Section: CP164 B
__updated__ = "2022-05-08"
-------------------------------------------------------
"""
from Queue_array import Queue
queue = Queue()

queue.insert(5)
queue.insert(6)
queue.insert(20)
print(f"Adding to Queue: {queue._values}")
value1 = queue.peek()
print()
print(f"Peek at Queue: {value1}")
print()
value2 = queue.remove()
print(f"Removing Values(s) Queue: {value2}")
print()
print(f"Queue: {queue._values}")
value3 = queue.peek()
print()
print(f"Peek at Queue: {value3}")
