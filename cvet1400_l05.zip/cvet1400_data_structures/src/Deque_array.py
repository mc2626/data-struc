"""
-------------------------------------------------------
Array version of the Deque ADT.
-------------------------------------------------------
Author:  Mila Cvetanovska
ID:      210311400
Email:   cvet1400@mylaurier.ca
Section: CP164 C
__updated__ = "2022-06-06"
-------------------------------------------------------
"""

from copy import deepcopy


class Deque:

    def __init__(self):
        """
        -------------------------------------------------------
        Initializes an is_empty deque. Data is stored in a Python list.
        Use: d = Deque()
        -------------------------------------------------------
        Returns:
            a new Deque object (Deque)
        -------------------------------------------------------
        """
        self._values = []

    def __len__(self):
        """
        -------------------------------------------------------
        Returns the number of values in the deque.
        Use: n = len(source)
        -------------------------------------------------------
        Returns:
            the number of values in the deque.
        -------------------------------------------------------
        """
        return len(self._values)

    def is_empty(self):
        """
        -------------------------------------------------------
        Determines if the deque is empty.
        Use: b = d.is_empty()
        -------------------------------------------------------
        Returns:
            True if the deque is empty, False otherwise
        -------------------------------------------------------
        """
        return (len(self._values) == 0)

    def insert_front(self, val):
        """
        -------------------------------------------------------
        Inserts a copy of value into the front of the deque.
        Use: deque.insert_front(value)
        -------------------------------------------------------
        Parameters:
            value - a data element (?)
        Returns:
            None
        -------------------------------------------------------
        """
        self._values.insert(0, deepcopy(val))

        return None

    def insert_rear(self, val):
        """
        -------------------------------------------------------
        Inserts a copy of value into the rear of the deque.
        Use: deque.insert_rear(value)
        -------------------------------------------------------
        Parameters:
            value - a data element (?)
        Returns:
            None
        -------------------------------------------------------
        """
        self._values.append(deepcopy(val))

        return None

    def remove_front(self):
        """
        -------------------------------------------------------
        Removes and returns value from the front of the deque.
        Use: v = deque.remove_front()
        -------------------------------------------------------
        Returns:
            value - the value at the front of deque (?)
        -------------------------------------------------------
        """
        assert not self.is_empty(), 'Queue is empty!'

        return self._values.pop(0)

    def remove_rear(self):
        """
        -------------------------------------------------------
        Removes and returns value from the rear of the deque.
        Use: v = deque.remove_rear()
        -------------------------------------------------------
        Returns:
            value - the value at the rear of deque (?)
        -------------------------------------------------------
        """
        assert not self.is_empty(), 'Queue is empty!'

        return self._values.pop(-1)

    def peek_front(self):
        """
        -------------------------------------------------------
        Peeks at the front of deque.
        Use: v = deque.peek_front()
        -------------------------------------------------------
        Returns:
            value - a copy of the value at the front of deque (?)
        -------------------------------------------------------
        """
        assert not self.is_empty(), 'Queue is empty!'

        return deepcopy(self._values[0])

    def peek_rear(self):
        """
        -------------------------------------------------------
        Peeks at the rear of deque.
        Use: v = deque.peek_rear()
        -------------------------------------------------------
        Returns:
            value - a copy of the value at the rear of deque (?)
        -------------------------------------------------------
        """
        assert not self.is_empty(), 'Queue is empty!'

        return deepcopy(self._values[-1])

    def _swap(self, i, j):
        """
        -------------------------------------------------------
        Swaps two nodes within a deque. l has taken the place of r,
        r has taken the place of l and _front and _rear are updated
        as appropriate. Data is not moved.
        Use: self._swap(self, l, r):
        -------------------------------------------------------
        Parameters:
            l - a pointer to a deque node (_Deque_Node)
            r - a pointer to a deque node (_Deque_Node)
        Returns:
            None
        -------------------------------------------------------
        """
        assert not self.is_empty(), 'Queue is empty!'

        cont = True
        k = j
        if i < j:
            k = i
        while cont:
            if k == i:
                val = deepcopy(self._values[k])
                self._values[k] = deepcopy(self._values[j])
                self._values[j] = val
                cont = False
            k += 1

        return None

    def __iter__(self):
        """
        USE FOR TESTING ONLY
        -------------------------------------------------------
        Generates a Python iterator. Iterates through the deque
        from front to rear.
        Use: for v in d:
        -------------------------------------------------------
        Returns:
            yields
            value - the next value in the deque (?)
        -------------------------------------------------------
        """
        yield from self._values
