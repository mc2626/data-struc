"""
-------------------------------------------------------
T01
-------------------------------------------------------
Author:  Mila Cvetanovska
ID:      210311400
Email:   cvet1400@mylaurier.ca
Section: CP164 B
__updated__ = "2022-05-02"
-------------------------------------------------------
"""
# Imports
from Stack_array import Stack
s = Stack()

b = s.is_empty()
print(f"Is Stack empty?: {b}\n")
print(f"Pushing values on Stack: \n")
s.push(5)
s.push(12)
s.push(23)
for value in s:
    print(value)
b = s.is_empty()
print(f"\nIs Stack empty?: {b}\n")
value = s.peek()
print(f"Peek value: {value}\n")

# -----------------------------------------
# def reverse()

s.reverse()
print(f"Stack Reversed: \n")
for value in s:
    print(value)
value = s.peek()
print(f"\nPeek value: {value}\n")

# -----------------------------------------
# def combine()

source1 = Stack()
source2 = Stack()

source1.push(1)
source1.push(2)
source1.push(3)
source1.push(4)
source1.push(5)

source2.push(6)
source2.push(7)
source2.push(8)
source2.push(9)
source2.push(10)

print(f"Source1 Stack: \n")
for value in source1:
    print(value)

print(f"\nSource2 Stack: \n")
for value in source2:
    print(value)

b = s.is_empty()
print(f"\nIs Target Stack empty?: {b}\n")


s.combine(source1, source2)

print(f"Combining Source1 and Source2 into Target Stack: \n")
for value in s:
    print(value)

b = source1.is_empty()
print(f"\nIs Source1 Stack empty?: {b}\n")

b = source2.is_empty()
print(f"\nIs Source2 Stack empty?: {b}\n")

# -----------------------------------------
# def split_alt()

target1 = Stack()
target2 = Stack()

s.push(1)
s.push(2)
s.push(3)
s.push(4)
s.push(5)
s.push(6)
s.push(7)
s.push(8)
s.push(9)
s.push(10)

print(f"Source Stack: \n")
for value in s:
    print(value)

target1, target2 = s.split_alt()

print(f"\nTarget1 Stack: \n")
for value in target1:
    print(value)

print(f"\nTarget2 Stack: \n")
for value in target2:
    print(value)

b = s.is_empty()
print(f"\nIs Source Stack empty?: {b}\n")
