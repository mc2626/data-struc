"""
-------------------------------------------------------
t02 - Sorted_List()
-------------------------------------------------------
Author:  Your Name
ID:      Your ID
Email:   your email@mylaurier.ca
__updated__ = "2022-06-07"
-------------------------------------------------------
"""
# Imports
from Sorted_List_array import Sorted_List

source = Sorted_List()

lst1 = [5, 3, 1, 2, 3, 4, 5, 6, 3, 3, 3]
# lst2 = [5, 20, 13, 16, 9, 0]
# lst3 = [0, 0, 0, 0]
# lst4 = []

key = 3
print(f"Key: {key}")
print()
for i in lst1:
    source.insert(i)
print(f"Source: {source._values}")

n = source.count(key)
print(f"Count: {n}")

i = source._binary_search(key)
print(f"Index of key: {i}")

b = key in source
print(f"Is key in source: {b}")

value = source.remove(key)
print(f"Remove: {value}")
print(f"Source: {source._values}")

n = source.count(key)
print(f"Count: {n}")
i = source._binary_search(key)
print(f"Index of key: {i}")
print()
print(f"_______________________________")
print()
print(f"def remove_many()")
print()

source.remove_many(key)
print(f"Source: {source._values}")

n = source.count(key)
print(f"Count: {n}")
print()
print(f"_________________________________")
print()
print(f"def clean()")
print()

source.clean()
print(f"Source: {source._values}")
print()
print(f"__________________________________")
print()
print(f"def find()")
print()

source.insert(3)
print(f"Inserting value 3: {source._values}")

value = source.find(key)
print(f"Value to find: {value}")

print(f"__________________________________")
print()
print(f"def combine()")
print()

source1 = Sorted_List()
source2 = Sorted_List()
target = Sorted_List()

lst = [3, 4, 5, 1, 2]
lstt = [6, 9, 10, 7, 8]

for i in lst:
    source1.insert(i)
print(f"Source: {source1._values}")

for i in lstt:
    source2.insert(i)
print(f"Source: {source2._values}")
print(f"Target: {target._values}")
print()

target.combine(source1, source2)
print(f"Source: {source1._values}")
print(f"Source: {source2._values}")
print(f"Source: {target._values}")

print(f"__________________________________")
print()
print(f"def interesection()")
print()

source1 = Sorted_List()
source2 = Sorted_List()
target = Sorted_List()

lst = [3, 4, 5, 1, 2]
lstt = [6, 4, 10, 7, 8]

for i in lst:
    source1.insert(i)
print(f"Source: {source1._values}")

for i in lstt:
    source2.insert(i)
print(f"Source: {source2._values}")
print(f"Target: {target._values}")
print()

target.intersection(source1, source2)
print(f"Source: {source1._values}")
print(f"Source: {source2._values}")
print(f"Source: {target._values}")

print(f"__________________________________")
print()
print(f"def is_identical()")
print()

source = Sorted_List()
target = Sorted_List()

lst = [10, 9, 6, 3, 2]
lstt = [10, 9, 6, 3, 2]

for i in lst:
    source.insert(i)
print(f"Source: {source._values}")

for i in lstt:
    target.insert(i)
print(f"Target: {target._values}")
print()

b = source.is_identical(target)
print(f"Is Source identical to Target: {b}")
print()
print(f"__________________________________")
print()
print(f"def split()")
print()

target1 = Sorted_List()
target2 = Sorted_List()
source = Sorted_List()

lst = [3, 4, 5, 1, 2]
lstt = [6, 4, 10, 7, 8]

for i in lst:
    source.insert(i)
print(f"Source: {source._values}")
print(f"Target1: {target1._values}")
print(f"Target2: {target2._values}")
print()

target1, target2 = source.split()
print(f"Target1: {target1._values}")
print(f"Target2: {target2._values}")
print(f"Source: {source._values}")
print()
print(f"Is Source identical to Target: {b}")
print()
print(f"__________________________________")
print()
print(f"def split_alt()")
print()

target1 = Sorted_List()
target2 = Sorted_List()
source = Sorted_List()

lst = [3, 4, 5, 1, 2]
lstt = [6, 4, 10, 7, 8]

for i in lst:
    source.insert(i)
print(f"Source: {source._values}")
print(f"Target1: {target1._values}")
print(f"Target2: {target2._values}")
print()

target1, target2 = source.split_alt()
print(f"Target1: {target1._values}")
print(f"Target2: {target2._values}")
print(f"Source: {source._values}")
print()
print(f"Source: {source1._values}")
print(f"Source: {source2._values}")
print(f"Source: {target._values}")
print()
print(f"__________________________________")
print()
print(f"def split_key()")
print()

source = Sorted_List()
target1 = Sorted_List()
target2 = Sorted_List()
key = 11

lst = [10, 9, 6, 3, 2]

for i in lst:
    source.insert(i)
print(f"Source: {source._values}")
print(f"Target1: {target1._values}")
print(f"Target2: {target2._values}")
print()

target1, target2 = source.split_key(key)

print(f"Source: {source._values}")
print(f"Target1: {target1._values}")
print(f"Target2: {target2._values}")
print()
print(f"__________________________________")
print()
print(f"def union()")
print()

source1 = Sorted_List()
source2 = Sorted_List()
target = Sorted_List()

lst = [11, 12]
lstt = [11, 55, 22, 44, 33]

for i in lst:
    source1.insert(i)
print(f"Source: {source1._values}")

for i in lstt:
    source2.insert(i)
print(f"Source: {source2._values}")
print(f"Target: {target._values}")
print()

target.union(source1, source2)
print(f"Source: {source1._values}")
print(f"Source: {source2._values}")
print(f"Target: {target._values}")
print()
print(f"__________________________________")
print()
print(f"def split_apply()")
print()

source = Sorted_List()
target1 = Sorted_List()
target2 = Sorted_List()


def func(value):
    value = source.is_empty()
    return value


lst = [10, 9, 6, 3, 2]

for i in lst:
    source.insert(i)
print(f"Source: {source._values}")
print(f"Target1: {target1._values}")
print(f"Target2: {target2._values}")
print()

target1, target2 = source.split_apply(func)

print(f"Source: {source._values}")
print(f"Target1: {target1._values}")
print(f"Target2: {target2._values}")
