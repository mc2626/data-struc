"""
-------------------------------------------------------
T06
-------------------------------------------------------
Author:  Mila Cvetanovska
ID:      210311400
Email:   cvet1400@mylaurier.ca
Section: CP164 B
__updated__ = "2022-05-13"
-------------------------------------------------------
"""
from functions import matrix_transpose

# a = [[]]
# a = [[1, 2, 3]]
a = [[0, 1], [2, 3], [4, 5], [6, 7], [8, 9]]
# a = [[1, 2, 3], [4, 5, 6], [7, 8, 9]]
# a = [[1, 1, 1, 1], [1, 1, 1, 1]]
# a = [[1, 1], [1, 1], [1, 1], [1, 1]]
# # a = [["a", "b"], ["c", "d"], ["e", "f"]]
# a = [[1], [2], [3]]
# a = [[0]]
# a = [[0, 0], [0, 0], [0, 0]]
print(f"Original: {a}")
b = matrix_transpose(a)
print(f"Transposed: {b}")
print()


# a = [[0, 1], [2, 3], [4, 5], [6, 7], [8, 9]]
# for i in a:
#     for j in i[:1]:
#         print(j)
#     for k in i[:]:
#         print(k)
# a = [["mila", "tanja"], ["zlatko", "eva"], ["bella", "charlie"]]

# for i in a:
#     for j in range(0, len(i) - 1, 1):
#         print(i[j], end=" ")
#         print(i[j + 1])
# b = matrix_transpose(a)
# print()
# for i in b:
#     for j in range(0, len(i) - 1, 1):
#         print(i[j], end=" ")
#         print(i[j + 1], end="\n")

# output
# b = [[0, 2, 4, 6, 8], [1, 3, 5, 7, 9]]
