"""
-------------------------------------------------------
T04
-------------------------------------------------------
Author:  Mila Cvetanovska
ID:      210311400
Email:   cvet1400@mylaurier.ca
Section: CP164 B
__updated__ = "2022-05-09"
-------------------------------------------------------
"""
from Priority_Queue_array import Priority_Queue
pq = Priority_Queue()

pq.insert(55)
pq.insert(11)
pq.insert(22)
pq.insert(33)
pq.insert(44)

print(f"Inserting Values in Pq: {pq._values}")
