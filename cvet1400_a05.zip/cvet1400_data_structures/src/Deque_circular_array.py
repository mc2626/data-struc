"""
-------------------------------------------------------
Python implementation of Dequeue using circular array
-------------------------------------------------------
Author:  Your Name
ID:      Your ID
Email:   your email@mylaurier.ca
__updated__ = "2022-06-06"
-------------------------------------------------------
"""
# Imports
from copy import deepcopy

DEFAULT_SIZE = 10


class Deque_circular:

    def __init__(self, capacity=DEFAULT_SIZE):
        """
        -------------------------------------------------------
        Initializes an is_empty deque. Data is stored in a Python list.
        Use: d = Deque_circular()
        -------------------------------------------------------
        Returns:
            a new Deque object (Deque)
        -------------------------------------------------------
        """
        # Maximum capacity of Python list to store data.
        self._capacity = capacity
        # Python list that stores data - initialized to list of None.
        self._values = [None] * self._capacity
        # Index of value at the front of Deque  - initialized to -1
        self._front = -1
        # Index of value at the rear of Deque  - initialized to -1
        self._rear = -1
        # Number of values in Deque. Cannot exceed _capacity.
        self._count = 0

    def is_full(self):
        """
        -------------------------------------------------------
        Determines if the deque is full.
        Use: b = d.is_full()
        -------------------------------------------------------
        Returns:
            True if the deque is full, False otherwise
        -------------------------------------------------------
        """
        return self._count == self._capacity

    def is_empty(self):
        """
        -------------------------------------------------------
        Determines if the deque is empty.
        Use: b = d.is_empty()
        -------------------------------------------------------
        Returns:
            True if the deque is empty, False otherwise
        -------------------------------------------------------
        """
        return self._count == 0

    def insert_front(self, value):
        """
        -------------------------------------------------------
        Inserts a copy of value into the front of the deque.
        Updates: self._front
        Updates: self._rear
        Updates: self._count
        Use: deque.insert_front(value)
        -------------------------------------------------------
        Parameters:
            value - a data element (?)
        Returns:
            None
        -------------------------------------------------------
        """
        assert not self._count == self._capacity, 'Deque is full!'

        # If queue is initially empty
        if self._front == -1:
            self._front = 0
            self._rear = 0

        # front is at first position of queue
        elif self._front == 0:
            self._front = self._capacity - 1

        else:  # decrement front end by '1'
            self._front -= 1

        # insert current element into Deque
        self._values[self._front] = deepcopy(value)

        self._count += 1

        return None

    def insert_rear(self, value):
        """
        -------------------------------------------------------
        Inserts a copy of value into the rear of the deque.
        Updates: self._front
        Updates: self._rear
        Updates: self._count
        Use: deque.insert_rear(value)
        -------------------------------------------------------
        Parameters:
            value - a data element (?)
        Returns:
            None
        -------------------------------------------------------
        """
        assert not self._count == self._capacity, 'Deque is full!'

        # If queue is initially empty
        if self._front == -1:
            self._front = 0
            self._rear = 0

        # rear is at last position of queue
        elif self._rear == self._capacity - 1:
            self._rear = 0

        # increment rear end by '1'
        else:
            self._rear += 1

        # insert current element into Deque
        self._values[self._rear] = deepcopy(value)

        self._count += 1

        return None

    def remove_front(self):
        """
        -------------------------------------------------------
        Removes and returns value from the front of the deque.
        Updates: self._front
        Updates: self._rear
        Updates: self._count
        Use: v = deque.remove_front()
        -------------------------------------------------------
        Returns:
            value - the value at the front of deque (?)
        -------------------------------------------------------
        """
        assert self._count != 0, 'Deque is empty!'
        value = None

        # Deque has only one element
        if self._front == self._rear:
            self._front = -1
            self._rear = -1
            value = deepcopy(self._values[self._front])
            self._values[self._front] = None
        else:
            # back to initial position
            if self._front == self._capacity - 1:
                value = deepcopy(self._values[self._front])
                self._values[self._front] = None
                self._front = 0
            else:  # increment front by '1' to remove current
                # front value from Deque
                value = deepcopy(self._values[self._front])
                self._values[self._front] = None
                self._front += 1

        self._count -= 1

        return value

    def remove_rear(self):
        """
        -------------------------------------------------------
        Removes and returns value from the rear of the deque.
        Updates: self._front
        Updates: self._rear
        Updates: self._count
        Use: v = deque.remove_rear()
        -------------------------------------------------------
        Returns:
            value - the value at the rear of deque (?)
        -------------------------------------------------------
        """
        assert self._count != 0, 'Deque is empty!'

        # Deque has only one element
        if self._front == self._rear:
            self._front = -1
            self._rear = -1
            value = deepcopy(self._values[self._rear])
            self._values[self._rear] = None

        elif self._rear == 0:
            self._rear = self._capacity - 1
            value = deepcopy(self._values[self._rear])
            self._values[self._rear] = None
        else:
            value = deepcopy(self._values[self._rear])
            self._values[self._rear] = None
            self._rear -= 1
        self._count -= 1

        return value

    def peek_front(self):
        """
        -------------------------------------------------------
        Peeks at the front of deque.
        Use: v = deque.peek_front()
        -------------------------------------------------------
        Returns:
            value - a copy of the value at the front of deque (?)
        -------------------------------------------------------
        """
        assert not self._count == 0, 'Deque is empty!'

        return self._values[self._front]

    def peek_rear(self):
        """
        -------------------------------------------------------
        Peeks at the rear of deque.
        Use: v = deque.peek_rear()
        -------------------------------------------------------
        Returns:
            value - a copy of the value at the rear of deque (?)
        -------------------------------------------------------
        """
        assert not self._count == 0, 'Deque is empty!'

        return self._values[self._rear]

    def __iter__(self):
        """
        USE FOR TESTING ONLY
        -------------------------------------------------------
        Generates a Python iterator. Iterates through the deque
        from front to rear.
        Use: for v in d:
        -------------------------------------------------------
        Returns:
            yields
            value - the next value in the deque (?)
        -------------------------------------------------------
        """
        yield from self._values
