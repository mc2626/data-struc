"""
-------------------------------------------------------
t04
-------------------------------------------------------
Author:  Mila Cvetanovska
ID:      210311400
Email:   cvet1400@mylaurier.ca
Section: CP164 B
__updated__ = "2022-05-06"
-------------------------------------------------------
"""
from Movie_utilities import get_by_genres, read_movies

fv = open('movies.txt', 'r')
movies = read_movies(fv)
fv.close

genres = []
genre = input("Enter a genre code: ")
while genre != "":
    if int(genre) >= 0 and int(genre) <= 10:
        genres.append(int(genre))
    genre = input("Enter a genre code: ")
print(f"List of genres: {genres}")

gmovies = get_by_genres(movies, genres)

print()
for movie in gmovies:
    print(movie)
    print()
