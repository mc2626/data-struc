"""
-------------------------------------------------------
T09
-------------------------------------------------------
Author:  Mila Cvetanovska
ID:      210311400
Email:   cvet1400@mylaurier.ca
Section: CP164 B
__updated__ = "2022-05-12"
-------------------------------------------------------
"""
from functions import shift

# string = "David"
# n = 1
# estring = shift(string, n)
# print(f"Estring: {estring}")

#-------------------------------------------------
# Testing with pelee.txt file

# Writing to shift.txt file
fv = open('pelee.txt', 'r')
f = open("shift.txt", "w")
n = 1
for line in fv:
    for word in line:
        string = word
        estring = shift(string, n)
        f.write(f"{estring}")
f.close()
fv.close()

# open and read the file after the appending:
f = open("shift.txt", "r")
print(f.read())
