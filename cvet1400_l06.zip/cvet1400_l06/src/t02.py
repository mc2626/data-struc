"""
-------------------------------------------------------
T02
-------------------------------------------------------
Author:  Your Name
ID:      Your ID
Email:   your email@mylaurier.ca
__updated__ = "2022-05-28"
-------------------------------------------------------
"""
# Imports
from List_linked import List

lst = List()
SEP = "_" * 60

lst.append(1)
lst.append(2)
lst.append(3)
lst.append(3)
lst.append(5)
print(f"Append: ")
for i in lst:
    print(i)

key = 5
previous, current, index = lst._linear_search(key)
print()
print(f"Previous: {previous._value}")
print(f"Current: {current._value}")
print(f"Index: {index}")
