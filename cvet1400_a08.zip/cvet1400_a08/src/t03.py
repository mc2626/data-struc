"""
-------------------------------------------------------
T03
-------------------------------------------------------
Author:  Your Name
ID:      Your ID
Email:   your email@mylaurier.ca
__updated__ = "2022-06-30"
-------------------------------------------------------
"""
# Imports
from BST_linked import BST
from Letter import Letter
from functions import do_comparisons, letter_table, DATA2

bst = BST()

# open file for reading
fv = open("miserables.txt", "r")

# using DATA2
for val in DATA2:
    obj = Letter(val)
    bst.insert(obj)

do_comparisons(fv, bst)

letter_table(bst)
