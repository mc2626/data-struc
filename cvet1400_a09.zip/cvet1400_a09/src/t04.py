"""
-------------------------------------------------------
T04
-------------------------------------------------------
Author:  Your Name
ID:      Your ID
Email:   your email@mylaurier.ca
__updated__ = "2022-07-05"
-------------------------------------------------------
"""
# Imports
from BST_linked import BST

# Constants
SEP = "_" * 60

# contains
bst = BST()
lst = []
for i in lst:
    bst.insert(i)
key = 0
b = key in bst
print(f"BST: {bst.levelorder()}")
print(f"Contains {key}? : {b}")
print()

bst = BST()
lst = [99]
for i in lst:
    bst.insert(i)
key = 0
b = key in bst
print(f"BST: {bst.levelorder()}")
print(f"Contains {key}? : {b}")
print()

bst = BST()
lst = [99]
for i in lst:
    bst.insert(i)
key = 99
b = key in bst
print(f"BST: {bst.levelorder()}")
print(f"Contains {key}? : {b}")
print()

bst = BST()
lst = [3, 1, 5, 0, 2, 4, 6]
for i in lst:
    bst.insert(i)
key = 5
b = key in bst
print(f"BST: {bst.levelorder()}")
print(f"Contains {key}? : {b}")
print()

bst = BST()
lst = [3, 1, 5, 0, 2, 4, 6]
for i in lst:
    bst.insert(i)
key = 99
b = key in bst
print(f"BST: {bst.levelorder()}")
print(f"Contains {key}? : {b}")
print()
print(SEP)
print()

# node_counts
bst = BST()
lst = []
for i in lst:
    bst.insert(i)
zero, one, two = bst.node_counts()
print(f"BST: {bst.levelorder()}")
print()
print(f"Zero Childern: {zero}")
print(f"One Child: {one}")
print(f"Two Childern: {two}")
print()

lst = [99]
for i in lst:
    bst.insert(i)
zero, one, two = bst.node_counts()
print(f"BST: {bst.levelorder()}")
print()
print(f"Zero Childern: {zero}")
print(f"One Child: {one}")
print(f"Two Childern: {two}")
print()

bst = BST()
lst = [0, 1]
for i in lst:
    bst.insert(i)
zero, one, two = bst.node_counts()
print(f"BST: {bst.levelorder()}")
print()
print(f"Zero Childern: {zero}")
print(f"One Child: {one}")
print(f"Two Childern: {two}")
print()

bst = BST()
lst = [3, 1, 5, 0, 2, 4, 6]
for i in lst:
    bst.insert(i)
zero, one, two = bst.node_counts()
print(f"BST: {bst.levelorder()}")
print()
print(f"Zero Childern: {zero}")
print(f"One Child: {one}")
print(f"Two Childern: {two}")
print()
print(SEP)
print()

# parent
bst = BST()
lst = [99]
for i in lst:
    bst.insert(i)
key = 0
value = bst.parent(key)
print(f"Parent Node of key: {key} is {value}")
print()

bst = BST()
lst = [3, 1, 5, 0, 2, 4, 6]
for i in lst:
    bst.insert(i)
key = 5
value = bst.parent(key)
print(f"Parent Node of key: {key} is {value}")
print()

bst = BST()
lst = [3, 1, 5, 0, 2, 4, 6]
for i in lst:
    bst.insert(i)
key = 99
value = bst.parent(key)
print(f"Parent Node of key: {key} is {value}")
print()
print(SEP)
print()

# parent_r
bst = BST()
lst = [99]
for i in lst:
    bst.insert(i)
key = 0
value = bst.parent_r(key)
print(f"Parent Node of key: {key} is {value}")
print()

bst = BST()
lst = [3, 1, 5, 0, 2, 4, 6]
for i in lst:
    bst.insert(i)
key = 5
value = bst.parent_r(key)
print(f"Parent Node of key: {key} is {value}")
print()

bst = BST()
lst = [3, 1, 5, 0, 2, 4, 6]
for i in lst:
    bst.insert(i)
key = 99
value = bst.parent_r(key)
print(f"Parent Node of key: {key} is {value}")
print()
