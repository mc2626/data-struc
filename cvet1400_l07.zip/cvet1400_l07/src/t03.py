"""
-------------------------------------------------------
T03
-------------------------------------------------------
Author:  Your Name
ID:      Your ID
Email:   your email@mylaurier.ca
__updated__ = "2022-06-18"
-------------------------------------------------------
"""
# Imports
from List_linked import List

print("-----------------------------------------------------")
print(f"def reverse: ")
print()

source = List()
lst = [1, 2, 3, 4, 5]
for i in lst:
    source.insert(0, i)
print(f"Original: ")
for i in source:
    print(i)
print()
print(f"Reversed: ")
source.reverse_r()
for i in source:
    print(i)
