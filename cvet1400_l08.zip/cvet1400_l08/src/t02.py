"""
-------------------------------------------------------
T02
-------------------------------------------------------
Author:  Your Name
ID:      Your ID
Email:   your email@mylaurier.ca
__updated__ = "2022-06-25"
-------------------------------------------------------
"""
# Imports
from BST_linked import BST
from morse import fill_code_bst, decode_morse

bst = BST()
values = (('A', '.-'), ('B', '-...'), ('C', '-.-.'),
          ('D', '-..'), ('E', '.'), ('F', '..-.'),
          ('G', '--.'), ('H', '....'), ('I', '..'),
          ('J', '.---'), ('K', '-.-'), ('L', '.-..'),
          ('M', '--'), ('N', '-.'), ('O', '---'),
          ('P', '.--.'), ('Q', '--.-'), ('R', '.-.'),
          ('S', '...'), ('T', '-'), ('U', '..--'),
          ('V', '...-'), ('W', '.--'), ('X', '-..-'),
          ('Y', '-.--'), ('Z', '--..'))

fill_code_bst(bst, values)
code = "... --- ..."

print(f"Morse Code: ")
print(f"... --- ...")
print()
text = decode_morse(bst, code)
print(f"English: ")
print(text)
