"""
-------------------------------------------------------
T01
-------------------------------------------------------
Author:  Your Name
ID:      Your ID
Email:   your email@mylaurier.ca
__updated__ = "2022-07-10"
-------------------------------------------------------
"""
# Imports
from Sorts_array import Sorts

# a = [100, 3, 0, 1000, 16, 10000, 20, 15, 10, 9,
#      18, 4, 7, 0, 4000000]
a = [1346, 23, 456, 199986, 22, 0]
print(f"Unsorted: {a}")
print()
Sorts.radix_sort(a)
print(f"Sorted: {a}")
print(f"Is Sorted? {Sorts.sort_test(a)}")
