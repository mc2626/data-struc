"""
-------------------------------------------------------
T01
-------------------------------------------------------
Author:  Mila Cvetanovska
ID:      210311400
Email:   cvet1400@mylaurier.ca
Section: CP164 B
__updated__ = "2022-05-17"
-------------------------------------------------------
"""
# Imports
from Movie import Movie
from List_array import List

# testing handling of keys (i.e None)
movie = Movie("mila", 2007, None, None, [1, 2, 3])
print(movie)

#-------------------------------------

# testing def_linear_search(key)

listt = List()

listt.append(1)
listt.append(2)
listt.append(3)
listt.append(4)
listt.append(5)

key = 4
i = listt._linear_search(key)
print(i)

#-----------------------------------

# testing __get_item__

value = listt[1]
print(value)
