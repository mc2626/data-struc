"""
-------------------------------------------------------
T05
-------------------------------------------------------
Author:  Your Name
ID:      Your ID
Email:   your email@mylaurier.ca
__updated__ = "2022-05-24"
-------------------------------------------------------
"""
# Imports
from functions import is_palindrome

s = "David"
# s = "Racecar"
palindrome = is_palindrome(s)
print(f"String: {s}")
print(f"Palindrome: {palindrome}")
