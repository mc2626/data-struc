"""
-------------------------------------------------------
T01
-------------------------------------------------------
Author:  Your Name
ID:      Your ID
Email:   your email@mylaurier.ca
__updated__ = "2022-05-24"
-------------------------------------------------------
"""
# Imports
from functions import recurse

x = 5
y = 7
ans = recurse(x, y)
print(f"x: {x}")
print(f"y: {y}")
print(f"Answer: {ans}")
