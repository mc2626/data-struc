"""
-------------------------------------------------------
T01
-------------------------------------------------------
Author:  Your Name
ID:      Your ID
Email:   your email@mylaurier.ca
__updated__ = "2022-05-27"
-------------------------------------------------------
"""
# Imports
from List_linked import List

lst = List()
SEP = "_" * 60

lst.prepend(1)
lst.prepend(2)
lst.prepend(3)
lst.prepend(4)
print(f"Prepend: ")
print()
for i in lst:
    print(i)
print(SEP)
lst.append(6)
lst.append(7)
lst.append(8)
print(f"Append: ")
print()
for i in lst:
    print(i)
print(SEP)
lst.insert(-1, 5)
lst.insert(0, 19)
lst.insert(12, 22)
lst.insert(-12, 34)
lst.insert(3, 18)
print(f"Insert: ")
print()
for i in lst:
    print(i)
print()
print(f"Count: {lst._count}")
