"""
-------------------------------------------------------
T03
-------------------------------------------------------
Author:  Your Name
ID:      Your ID
Email:   your email@mylaurier.ca
__updated__ = "2022-05-24"
-------------------------------------------------------
"""
# Imports
from functions import vowel_count

s = "Mily"
count = vowel_count(s)
print(f"String: {s}")
print(f"Vowel Count: {count}")
