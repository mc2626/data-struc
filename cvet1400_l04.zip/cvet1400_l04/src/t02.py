"""
-------------------------------------------------------
T02
-------------------------------------------------------
Author:  Mila Cvetanovska
ID:      210311400
Email:   cvet1400@mylaurier.ca
Section: CP164 B
__updated__ = "2022-05-17"
-------------------------------------------------------
"""
# Imports
from List_array import List

source = List()

source.append(99)
print(f"Source: {source._values}")
source.append(15)
print(f"Source: {source._values}")
source.insert(0, 1)
print(f"Source: {source._values}")
source.insert(0, 2)
print(f"Source: {source._values}")
source.insert(-2, 5)
print(f"Source: {source._values}")
source.insert(3, 4)
print(f"Source: {source._values}")
source.insert(10, 4)
print(f"Source: {source._values}")
source.insert(-10, 4)
print(f"Source: {source._values}")
source.insert(1, 10)
print(f"Source: {source._values}")
source.append(6)
print(f"Source: {source._values}")
