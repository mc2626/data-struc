"""
-------------------------------------------------------
T04
-------------------------------------------------------
Author:  Your Name
ID:      Your ID
Email:   your email@mylaurier.ca
__updated__ = "2022-05-24"
-------------------------------------------------------
"""
# Imports
from functions import to_power

base = 2
power = 3
ans = to_power(base, power)
print(f"base: {base}")
print(f"power: {power}")
print(f"Answer: {ans}")
