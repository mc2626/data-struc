"""
-------------------------------------------------------
def clean - List linked
-------------------------------------------------------
Author:  Your Name
ID:      Your ID
Email:   your email@mylaurier.ca
__updated__ = "2022-05-30"
-------------------------------------------------------
"""
# Imports
from List_linked import List

lst = List()
SEP = "_" * 60

lst.append(1)
lst.append(3)
lst.append(4)
lst.append(3)
lst.append(5)
lst.append(2)
lst.append(5)
lst.append(5)
print(f"Append: ")
print()
for i in lst:
    print(i)
print(SEP)
lst.clean()
print(f"Clean: ")
print()
for i in lst:
    print(i)
