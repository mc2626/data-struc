"""
-------------------------------------------------------
T02
-------------------------------------------------------
Author:  Your Name
ID:      Your ID
Email:   your email@mylaurier.ca
__updated__ = "2022-06-17"
-------------------------------------------------------
"""
# Imports
from List_linked import List

print("-----------------------------------------------------")
print(f"def split_alt: ")
print()

source = List()
target1 = List()
target2 = List()

lst1 = [11, 22, 33, 44, 55]  # works with: [], [99]
j = len(lst1) - 1
for i in lst1:
    source.insert(j, i)
j += 1
print(f"Source: ")
for i in source:
    print(i)
print()
print(f"Target1: ")
for i in target1:
    print(i)
print()
print(f"Target2: ")
for i in target2:
    print(i)
print()

target1, target2 = source.split_alt_r()
print()
print(f"Source: ")
for i in source:
    print(i)
print()
print(f"Target1: ")
for i in target1:
    print(i)
print()
print(f"Target2: ")
for i in target2:
    print(i)
