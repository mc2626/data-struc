"""
-------------------------------------------------------
T07
-------------------------------------------------------
Author:  Mila Cvetanovska
ID:      210311400
Email:   cvet1400@mylaurier.ca
Section: CP164 B
__updated__ = "2022-05-13"
-------------------------------------------------------
"""
from functions import matrix_stats

a = [[0, 1], [2, 3], [4, 5], [6, 7], [8, 9]]
# a = [[0, 0], [0, 0]]
# a = [[]]
# a = [[0]]
# a = [[10]]
# a = [[1, 1], [1, 1]]
# a = [[1, 1, 1, 1], [1, 1, 1, 1]]
# a = [[1, 1], [1, 1], [1, 1], [1, 1]]
# a = [[4, 5, 6], [3, 2, 1], [9, 8, 7]]
small, large, total, average = matrix_stats(a)
print(f"Small: {small}")
print(f"Large: {large}")
print(f"Total: {total}")
print(f"Average: {average}")
