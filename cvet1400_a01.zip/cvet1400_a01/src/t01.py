"""
-------------------------------------------------------
T01
-------------------------------------------------------
Author:  Mila Cvetanovska
ID:      210311400
Email:   cvet1400@mylaurier.ca
Section: CP164 B
__updated__ = "2022-05-13"
-------------------------------------------------------
"""
from functions import dsmvwl

s = "I think your book is an utter piece of Garbage."
# s = ""
# s = "A"
# s = "a"
# s = "B"
# s = "b"
# s = "a bAB o"
# s = "aye"

print(f"Sentence: {s}")
out = dsmvwl(s)
print(f"Disemvowelled: {out}")
