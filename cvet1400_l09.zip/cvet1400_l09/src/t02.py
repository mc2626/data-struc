"""
-------------------------------------------------------
T02
-------------------------------------------------------
Author:  Your Name
ID:      Your ID
Email:   your email@mylaurier.ca
__updated__ = "2022-07-03"
-------------------------------------------------------
"""
# Imports
from Hash_Set_array import Hash_Set
from Movie_utilities import read_movies

hs = Hash_Set(7)

fv = open('movies.txt', 'r')
movies = read_movies(fv)
fv.close

for movie in movies:
    hs.insert(movie)


hs.debug()
