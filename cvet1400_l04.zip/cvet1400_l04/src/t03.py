"""
-------------------------------------------------------
T03
-------------------------------------------------------
Author:  Mila Cvetanovska
ID:      210311400
Email:   cvet1400@mylaurier.ca
Section: CP164 B
__updated__ = "2022-05-17"
-------------------------------------------------------
"""
# Imports
from List_array import List


source = List()
source.insert(0, 99)
print(f"Source: {source._values}")
value = source.remove_front()
print(f"Removed Value: {value}")
print(f"Source: {source._values}")

print()
source.insert(0, 1)
source.insert(0, 2)
source.insert(-2, 5)
source.insert(3, 4)
source.insert(10, 4)
source.insert(-10, 4)
source.insert(1, 10)

print(f"Source: {source._values}")
value = source.remove_front()
print(f"Removed Value: {value}")
print(f"Source: {source._values}")
