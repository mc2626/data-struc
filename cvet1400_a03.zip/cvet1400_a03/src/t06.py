"""
-------------------------------------------------------
t06
-------------------------------------------------------
Author:  Mila Cvetanovska
ID:      210311400
Email:   cvet1400@mylaurier.ca
Section: CP164 B
__updated__ = "2022-05-08"
-------------------------------------------------------
"""
from functions import stack_maze


# maze = {'Start': ['A'], 'A': ['B', 'C'], 'B': [], 'C': [
#     'D', 'E'],  'D': [], 'E': ['F', 'X'], 'F': ['G', 'H'], 'G': [], 'H': []}

# # trival maze: Start --> X
# maze = {'Start': ['X']}
#
# # maze with circular path
# maze = {'Start': ['A'], 'A': ['B', 'C'], 'B': [], 'C': ['D', 'E'],
#         'D': [], 'E': ['X', 'F'], 'F': ['G'], 'G': ['C']}

# maze with no exit
maze = {'Start': ['A'], 'A': []}

path = stack_maze(maze)
print(f"Path: {path}")
