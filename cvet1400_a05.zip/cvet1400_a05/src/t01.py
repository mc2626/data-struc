"""
-------------------------------------------------------
t01 - List()
-------------------------------------------------------
Author:  Your Name
ID:      Your ID
Email:   your email@mylaurier.ca
__updated__ = "2022-06-07"
-------------------------------------------------------
"""
# Imports
from List_array import List


print("-----------------------------------------------------")
print(f"def clean: ")
print()

source = List()
# empty list
print(f"Source: {source._values} ")
source.clean()
print(f"Cleaning: {source._values}")
print()
# one value in list
source.insert(0, 99)
print(f"Source: {source._values} ")
source.clean()
print(f"Cleaning: {source._values}")
source.remove(99)
print()
# no duplicates in list
j = 0
lst = [11, 55, 22, 44, 33]
for i in lst:
    source.insert(j, i)
j += 1
print(f"Source: {source._values} ")
source.clean()
print(f"Cleaning: {source._values}")
source.remove(11)
source.remove(55)
source.remove(22)
source.remove(44)
source.remove(33)
print()
# all duplicates; source = []
lst = [99, 99, 99, 99, 99]
for i in lst:
    source.insert(j, i)
j += 1
print(f"Source: {source._values} ")
source.clean()
print(f"Cleaning: {source._values}")
print()
source.remove(99)
# all duplicates; source = []
lst = [11, 55, 22, 44, 33, 11, 55, 22, 44, 33]
for i in lst:
    source.insert(j, i)
j += 1
print(f"Source: {source._values} ")
source.clean()
print(f"Cleaning: {source._values}")
print()
print("-----------------------------------------------------")
print(f"def combine: ")
print()

target = List()
source1 = List()
source2 = List()

lst1 = [11, 2, 3, 4, 5]  # works with []
j = len(lst1) - 1
for i in lst1:
    source1.insert(j, i)
j += 1
print(f"Source1: {source1._values}")

print()

lst2 = [6, 7, 8, 9, 10]  # works with []
k = len(lst2) - 1
for i in lst2:
    source2.insert(k, i)
k += 1
print(f"Source2: {source2._values}")
print()
print(f"Target: {target._values}")
target.combine(source1, source2)
print()
print(f"Target: {target._values}")
print()
print(f"Source1: {source1._values}")
print()
print(f"Source2: {source2._values}")
print()

print("-----------------------------------------------------")
print(f"def intersection: ")
print()
target = List()
source1 = List()
source2 = List()

# test with: [], [1, 2, 3, 4], [1, 1, 1, 1], [1, 2, 3, 4, 5]
lst1 = [11, 55, 22, 44]
j = len(lst1) - 1
for i in lst1:
    source1.insert(j, i)
j += 1
print(f"Source1: {source1._values}")

print()

# test with: [], [1, 2, 3, 4], [1, 1, 1, 1], [6, 7, 8, 9, 10]
lst2 = [22, 44, 33]
k = len(lst2) - 1
for i in lst2:
    source2.insert(k, i)
k += 1
print(f"Source2: {source2._values}")
target.intersection(source1, source2)
print()
print(f"Target Intersection: {target._values}")
print()

print("-----------------------------------------------------")
print(f"def is_identical: ")
print()

target = List()
source = List()

lst1 = [11, 55, 22, 44, 33]
j = len(lst1) - 1
for i in lst1:
    source.insert(j, i)
j += 1
print(f"Source: {source._values}")
print()
lst2 = [11, 55, 22, 44, 33]
j = len(lst1) - 1
for i in lst2:
    target.insert(j, i)
j += 1
print(f"Target: {target._values}")
print()
b = source.is_identical(target)
print(f"Are both lists identical? : {b}")
print()

print("-----------------------------------------------------")
print(f"def split: ")
print()

source = List()
target1 = List()
target2 = List()

lst1 = [11, 22, 33, 44, 55]  # works with: [], [99]
j = len(lst1) - 1
for i in lst1:
    source.insert(j, i)
j += 1
print(f"Source1: {source._values}")
print(f"Target1: {target1._values}")
print(f"Target2: {target2._values}")

print()

target1, target2 = source.split()
print()
print(f"Source: {source._values}")
print()
print(f"Target1: {target1._values}")
print()
print(f"Target2: {target2._values}")
print()

print("-----------------------------------------------------")
print(f"def split_alt: ")
print()

source = List()
target1 = List()
target2 = List()

lst1 = [11, 22, 33, 44, 55]  # works with: [], [99]
j = len(lst1) - 1
for i in lst1:
    source.insert(j, i)
j += 1
print(f"Source1: {source._values}")
print(f"Target1: {target1._values}")
print(f"Target2: {target2._values}")

print()

target1, target2 = source.split_alt()
print()
print(f"Target1: {target1._values}")
print(f"Target2: {target2._values}")
print(f"Source: {source._values}")
print()

print("-----------------------------------------------------")
print(f"def union: ")
print()

target = List()
source1 = List()
source2 = List()

# test with: [], [1, 2, 3, 4], [1, 1, 1, 1], [1, 2, 3, 4, 5]
lst1 = [11, 12]
j = len(lst1) - 1
for i in lst1:
    source1.insert(j, i)
j += 1
print(f"Source1: {source1._values}")

print()

# test with: [], [1, 2, 3, 4], [1, 1, 1, 1], [6, 7, 8, 9, 10]
lst2 = [11, 55, 22, 44, 33]
k = len(lst2) - 1
for i in lst2:
    source2.insert(k, i)
k += 1
print(f"Source2: {source2._values}")
target.union(source1, source2)
print()
print(f"Target Union: {target._values}")
print(f"Source1: {source1._values}")
print(f"Source2: {source2._values}")
