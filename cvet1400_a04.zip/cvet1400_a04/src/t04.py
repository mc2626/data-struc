"""
-------------------------------------------------------
T04
-------------------------------------------------------
Author:  Your Name
ID:      Your ID
Email:   your email@mylaurier.ca
__updated__ = "2022-05-18"
-------------------------------------------------------
"""
# Imports
from Priority_Queue_array import Priority_Queue
from functions import pq_split_key

target1 = Priority_Queue()
target2 = Priority_Queue()

source = Priority_Queue()

print(f"Source: {source._values}")

lst = [55, 33, 22, 44, 11]
for i in lst:
    source.insert(i)
    i += 1

print(f"Target 1: {target1._values}")
print(f"Target 2: {target2._values}")
print()
key = 33

target1, target2 = pq_split_key(source, key)
print(f"Source: {source._values}")
print(f"Target 1: {target1._values}")
print(f"Target 2: {target2._values}")
