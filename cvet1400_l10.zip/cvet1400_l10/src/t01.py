"""
-------------------------------------------------------
T01
-------------------------------------------------------
Author:  Your Name
ID:      Your ID
Email:   your email@mylaurier.ca
__updated__ = "2022-07-06"
-------------------------------------------------------
"""
# Imports
from test_Sorts_array import SORTS, test_sort

test_sort(SORTS[0][0], SORTS[0][1])  # - bubble sort
print()
test_sort(SORTS[1][0], SORTS[1][1])  # - insertion sort
print()
test_sort(SORTS[10][0], SORTS[10][1])  # - shell sort
