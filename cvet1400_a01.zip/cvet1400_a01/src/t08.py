"""
-------------------------------------------------------
T08
-------------------------------------------------------
Author:  Mila Cvetanovska
ID:      210311400
Email:   cvet1400@mylaurier.ca
Section: CP164 B
__updated__ = "2022-05-05"
-------------------------------------------------------
"""
from functions import matrixes_multiply

a = [[0, 0]]
# a = [[1, 2], [3, 4], [5, 6]]
# a = [[1, 2, 3], [4, 5, 6], [7, 8, 9]]
print(f"Matrix A: ")
for i in a:
    print(i)
print()
b = [[1], [2]]
#b = [[10, 11, 12], [13, 14, 15], [16, 17, 18]]
print(f"Matrix B: ")
for i in b:
    print(i)
print()
# a = [[]]
c = matrixes_multiply(a, b)
print(f"Matrix Multiplication: ")
for i in c:
    print(i)
