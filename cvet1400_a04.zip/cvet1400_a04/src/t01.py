"""
-------------------------------------------------------
T01
-------------------------------------------------------
Author:  Your Name
ID:      Your ID
Email:   your email@mylaurier.ca
__updated__ = "2022-05-18"
-------------------------------------------------------
"""
# Imports
from Queue_circular import Queue
source = Queue()

print(f"Queue: {source._values}")
print()
source.insert(1)
source.insert(2)
source.insert(3)
source.insert(4)
source.insert(5)
source.insert(6)
source.insert(7)
source.insert(8)
source.insert(9)
source.insert(10)
print(f"Queue: {source._values}")
print()

# presents assertion error: "Cannot add to a full queue"
# source.insert(11)
# print(f"Queue: {source._values}")

v = source.remove()
print(f"Removed value: {v}")
print(f"Queue: {source._values}")
print()
v = source.remove()
print(f"Removed value: {v}")
print(f"Queue: {source._values}")
print()
print(f"Removing all values: ")
source.remove()
source.remove()
source.remove()
source.remove()
source.remove()
source.remove()
source.remove()
source.remove()
print(f"Queue: {source._values}")
empty = source.is_empty()
print(f"Is Queue Empty: {empty}")
print()

# presents assertion error: "Cannot remove from an empty queue"
# source.remove()
# print(f"Queue: {source._values}")

print(f"Inserting values: ")
source.insert(1)
source.insert(2)
source.insert(3)
source.insert(4)
source.insert(5)
print(f"Queue: {source._values}")
print()
v = source.remove()
print(f"Removed value: {v}")
print(f"Queue: {source._values}")
print()
v = source.remove()
print(f"Removed value: {v}")
print(f"Queue: {source._values}")
print()
v = source.remove()
print(f"Removed value: {v}")
print(f"Queue: {source._values}")
print()
print(f"Inserting values: ")
source.insert(1)
source.insert(2)
source.insert(3)
source.insert(4)
source.insert(5)
source.insert(6)
source.insert(7)
print(f"Queue: {source._values}")
empty = source.is_empty()
print(f"Is Queue Empty: {empty}")
v = source.peek()
print(f"Peek: {v}")
