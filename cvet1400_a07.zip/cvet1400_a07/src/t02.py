"""
-------------------------------------------------------
Sorted_List_linked
-------------------------------------------------------
Author:  Your Name
ID:      Your ID
Email:   your email@mylaurier.ca
__updated__ = "2022-06-28"
-------------------------------------------------------
"""
# Imports
from Sorted_List_linked import Sorted_List


rs = Sorted_List()
SEP = "_" * 60

print()
# insert doesn't work when adding same values to an empty list
# rs.insert(1)
# rs.insert(1)
# rs.insert(1)
# rs.insert(1)
# rs.insert(1)
rs.insert(2)
rs.insert(3)
rs.insert(0)
rs.insert(5)
rs.insert(2)
rs.insert(2)
rs.insert(4)
rs.insert(6)
print(f"def insert: ")
print()
for i in rs:
    print(i, end=" ")
print()
print(SEP)
key = 2
n = rs.count(key)
print(f"Key: {key}")
print(f"def count: {n}")
print(SEP)
value1 = rs.remove(2)
print(f"def remove: {value1}")
print()
for i in rs:
    print(i, end=" ")
print()
print(SEP)
value2 = rs.remove_front()
print(f"def remove_front: {value2}")
print()
for i in rs:
    print(i, end=" ")
print()
print(SEP)
print(f"def remove_many: ")
print()
key = 2
print(f"Key: {key}")
print()
rs.remove_many(key)
print(f"List: ")
print()
for i in rs:
    print(i, end=" ")
print()
print(SEP)
value3 = rs.peek()
print(f"def peek: {value3}")
print(SEP)
key = 5
b = key in rs
print(f"Key: {key}")
print()
print(f"def contain: {b}")
print(SEP)
rs.insert(2)
rs.insert(2)
rs.insert(2)
rs.insert(5)
rs.insert(2)
print(f"List: ")
print()
for i in rs:
    print(i, end=" ")
print()
print()
print(f"def clean: ")
rs.clean()
print()
for i in rs:
    print(i, end=" ")
print()
print(SEP)
print(f"def intersection")
print()
source1 = Sorted_List()
source2 = Sorted_List()
target = Sorted_List()
print(f"Source1: ")
lst1 = [0, 6, 2]
for i in lst1:
    source1.insert(i)
for i in source1:
    print(i, end=" ")
print()
print()
print(f"Source2: ")
lst2 = [6, 2, 7, 2]
for i in lst2:
    source2.insert(i)
for i in source2:
    print(i, end=" ")
print()
print()
print(f"Target: ")
for j in target:
    print(j, end=" ")
print()
print()
target.intersection(source1, source2)
print(f"Target: ")
for i in target:
    print(i, end=" ")
print()
print()
print(f"Source1: ")
for i in source1:
    print(i, end=" ")
print()
print()
print(f"Source2: ")
for i in source2:
    print(i, end=" ")
print()
print(SEP)
print(f"def union")
print()
source1 = Sorted_List()
source2 = Sorted_List()
target = Sorted_List()
print(f"Source1: ")
lst1 = [1, 2, 3, 2, 5]
for i in lst1:
    source1.insert(i)
for i in source1:
    print(i, end=" ")
print()
print()
print(f"Source2: ")
lst2 = [6, 2, 7, 2]
for i in lst2:
    source2.insert(i)
for i in source2:
    print(i, end=" ")
print()
print()
print(f"Target: ")
for j in target:
    print(j, end=" ")
print()
print()
target.union(source1, source2)
print(f"Target: ")
for i in target:
    print(i, end=" ")
print()
print()
print(f"Source1: ")
for i in source1:
    print(i, end=" ")
print()
print()
print(f"Source2: ")
for i in source2:
    print(i, end=" ")
print()
print(SEP)
print(f"def split_key")
print()
source = Sorted_List()
target1 = Sorted_List()
target2 = Sorted_List()
print(f"Source: ")
lst = [1, 2, 3, 4, 5]
for i in lst:
    source.insert(i)
for i in source:
    print(i, end=" ")
print()
print()
print(f"Target1: []")
for j in target1:
    print(j, end=" ")
print()
print()
print(f"Target2: []")
for j in target2:
    print(j, end=" ")
print()
print()
key = 3
target1, target2 = source.split_key(key)
print(f"Source: []")
for i in source:
    print(i, end=" ")
print()
print()
print(f"Target1: ")
for j in target1:
    print(j, end=" ")
print()
print()
print(f"Target2: ")
for j in target2:
    print(j, end=" ")
print()
print()
print(SEP)
print(f"def split_alt")
print()
source = Sorted_List()
even = Sorted_List()
odd = Sorted_List()
print(f"Source: ")
lst = [0, 1, 2, 3, 4, 5]
for i in lst:
    source.insert(i)
for i in source:
    print(i, end=" ")
print()
print()
print(f"Even: []")
for j in even:
    print(j, end=" ")
print()
print()
print(f"Odd: []")
for j in odd:
    print(j, end=" ")
print()
print()
even, odd = source.split_alt()
print(f"Source: []")
for i in source:
    print(i, end=" ")
print()
print()
print(f"Even: ")
for j in even:
    print(j, end=" ")
print()
print()
print(f"Odd: ")
for j in odd:
    print(j, end=" ")
print()
print(SEP)
print(f"def copy")
print()
source = Sorted_List()
new_list = Sorted_List()
print(f"Source: ")
lst = [0, 1, 2, 3, 4, 5]
for i in lst:
    source.insert(i)
for i in source:
    print(i, end=" ")
print()
print()
print(f"New_List: ")
for i in new_list:
    print(i)
print()
print()
new_list = source.copy()
print(f"Source: ")
for i in source:
    print(i, end=" ")
print()
print()
print(f"New_List: ")
for i in new_list:
    print(i, end=" ")
print()
print(SEP)
print(f"def split")
print()
source = Sorted_List()
target1 = Sorted_List()
target2 = Sorted_List()
print(f"Source: ")
lst = [1, 2, 3, 4, 5, 6]
for i in lst:
    source.insert(i)
for i in source:
    print(i, end=" ")
print()
print()
print(f"Target1: []")
for j in target1:
    print(j, end=" ")
print()
print()
print(f"Target2: []")
for j in target2:
    print(j, end=" ")
print()
print()
target1, target2 = source.split()
print(f"Source: []")
for i in source:
    print(i, end=" ")
print()
print()
print(f"Target1: ")
for j in target1:
    print(j, end=" ")
print()
print()
print(f"Target2: ")
for j in target2:
    print(j, end=" ")
print()
print(SEP)
print(f"def is_identical")  # sequence of tests doesn't work
print()
lst = Sorted_List()
other = Sorted_List()
lst.insert(0)
lst.insert(0)
lst.insert(0)
lst.insert(1)
lst.insert(0)
print(f"Lst: ")
print()
for i in lst:
    print(i, end=" ")
print()
print()
other.insert(0)
other.insert(0)
other.insert(0)
other.insert(0)
other.insert(0)
print(f"Other ")
print()
for i in other:
    print(i, end=" ")
print()
print()
b = lst.is_identical(other)
print(f"Is Identical: {b}")
print()
print(SEP)
print(f"def combine")  # sequence of tests doesn't work
print()
source1 = Sorted_List()
source2 = Sorted_List()
target = Sorted_List()
print(f"Source1: ")
lst1 = [1, 2, 3, 4, 5]
for i in lst1:
    source1.insert(i)
for i in source1:
    print(i, end=" ")
print()
print()
print(f"Source2: ")
lst2 = [6, 7, 8, 9, 10]
for i in lst2:
    source2.insert(i)
for i in source2:
    print(i, end=" ")
print()
print()
print(f"Target: []")
for j in target:
    print(j, end=" ")
print()
print()
target.combine(source1, source2)
print(f"Source1: []")
for i in source1:
    print(i, end=" ")
print()
print()
print(f"Source2: []")
for i in source2:
    print(i, end=" ")
print()
print()
print(f"Target: ")
for j in target:
    print(j, end=" ")
print()
print()
