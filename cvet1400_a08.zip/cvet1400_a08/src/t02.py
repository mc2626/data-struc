"""
-------------------------------------------------------
T02
-------------------------------------------------------
Author:  Your Name
ID:      Your ID
Email:   your email@mylaurier.ca
__updated__ = "2022-07-05"
-------------------------------------------------------
"""
# Imports
from BST_linked import BST
from Letter import Letter
from functions import do_comparisons, comparison_total, DATA1, DATA2, DATA3

# Constants
SEP = "_" * 60

# using DATA1
bst1 = BST()

for val in DATA1:
    obj = Letter(val)
    bst1.insert(obj)

print(f"Comparing by order: {DATA1}")

file_variable = open('miserables.txt', 'r')
do_comparisons(file_variable, bst1)
file_variable.close()

total = comparison_total(bst1)
print(f"Total Comparisons: {total:,}")
print(SEP)

# using DATA2
bst2 = BST()

for val in DATA2:
    obj = Letter(val)
    bst2.insert(obj)

print(f"Comparing by order: {DATA2}")

file_variable = open('miserables.txt', 'r')
do_comparisons(file_variable, bst2)
file_variable.close()

total = comparison_total(bst2)
print(f"Total Comparisons: {total:,}")
print(SEP)

# using DATA3
bst3 = BST()

for val in DATA3:
    obj = Letter(val)
    bst3.insert(obj)

print(f"Comparing by order: {DATA3}")

file_variable = open('miserables.txt', 'r')
do_comparisons(file_variable, bst3)
file_variable.close()

total = comparison_total(bst3)
print(f"Total Comparisons: {total:,}")
print(SEP)
