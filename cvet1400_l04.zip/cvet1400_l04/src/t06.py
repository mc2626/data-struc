"""
-------------------------------------------------------
T06
-------------------------------------------------------
Author:  Mila Cvetanovska
ID:      210311400
Email:   cvet1400@mylaurier.ca
Section: CP164 B
__updated__ = "2022-05-16"
-------------------------------------------------------
"""
# Imports
from List_array import List
from utilities import array_to_list, list_to_array

llist = List()
source = [1, 2, 3, 4, 5]

print(f"Array: {source}")
array_to_list(llist, source)
print()
print(f"List: {llist._values}")
print(f"Array: {source}")
#-----------------------------------------

llist = List()
target = []

llist.insert(0, 1)
llist.insert(1, 2)
llist.insert(2, 3)
llist.insert(3, 4)
llist.insert(4, 5)

print(f"Array: {llist._values}")
list_to_array(llist, target)
print()
print(f"Array: {target}")
print(f"List: {llist._values}")
