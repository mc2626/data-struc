"""
-------------------------------------------------------
t04
-------------------------------------------------------
Author:  Mila Cvetanovska
ID:      210311400
Email:   cvet1400@mylaurier.ca
Section: CP164 B
__updated__ = "2022-05-06"
-------------------------------------------------------
"""
from Stack_array import Stack
source = Stack()

source.push(5)
source.push(7)
source.push(8)
source.push(9)
source.push(12)
source.push(14)
source.push(8)

print(f"Source Stack: ")
for i in source:
    print(i)

value = source.peek()
print(f"\nPeek value: {value}\n")

source.reverse()
print(f"\nStack Reversed: \n")
for value in source:
    print(value)

value = source.peek()
print(f"\nPeek value: {value}\n")
