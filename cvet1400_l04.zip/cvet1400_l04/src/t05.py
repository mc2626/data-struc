"""
-------------------------------------------------------
T05
-------------------------------------------------------
Author:  Mila Cvetanovska
ID:      210311400
Email:   cvet1400@mylaurier.ca
Section: CP164 B
__updated__ = "2022-05-17"
-------------------------------------------------------
"""
# Imports
from List_array import List


source = List()

source.insert(0, 1)
source.insert(0, 2)
source.insert(-2, 5)
source.insert(3, 4)
source.insert(10, 4)
source.insert(-10, 4)
source.insert(1, 10)
source.insert(-10, 6)
print(source._values)

# lst = [99, 99, 99, 99, 99]
# j = 0
# for i in lst:
#     source.insert(j, i)
#     print(i)
#     j += 1
# print(source._values)


key = 4
source.remove_many(key)
print(source._values)
