"""
-------------------------------------------------------
T04
-------------------------------------------------------
Author:  Your Name
ID:      Your ID
Email:   your email@mylaurier.ca
__updated__ = "2022-05-28"
-------------------------------------------------------
"""
# Imports
from List_linked import List

lst = List()
SEP = "_" * 60

lst.append(1)
lst.append(2)
lst.append(6)
lst.append(3)
lst.append(5)
lst.append(6)
print(f"Append: ")
print()
for i in lst:
    print(i)
print(SEP)
key = 6
value = lst.find(key)
print(f"Find: {value}")
