"""
-------------------------------------------------------
T02
-------------------------------------------------------
Author:  Your Name
ID:      Your ID
Email:   your email@mylaurier.ca
__updated__ = "2022-07-10"
-------------------------------------------------------
"""
# Imports
from Sorts_List_linked import Sorts
from List_linked import List

lst = List()
a = [1346, 23, 456, 199986, 22, 0]
# a = [20, 15, 10, 9, 18, 4, 7, 0]
for i in a:
    lst.append(i)
print(f"Unsorted: ")
for v in lst:
    print(v, end=" ")
print()
print()
Sorts.radix_sort(lst)
print(f"Sorted: ")
for v in lst:
    print(v, end=" ")
print()
print(f"Is Sorted? {Sorts.sort_test(lst)}")
