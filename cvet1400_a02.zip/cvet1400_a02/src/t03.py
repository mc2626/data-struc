"""
-------------------------------------------------------
t03
-------------------------------------------------------
Author:  Mila Cvetanovska
ID:      210311400
Email:   cvet1400@mylaurier.ca
Section: CP164 B
__updated__ = "2022-05-17"
-------------------------------------------------------
"""
from Movie_utilities import get_by_genre, read_movies

fv = open('movies.txt', 'r')
movies = read_movies(fv)
fv.close

genre = int(input("Enter a genre code: "))
gmovies = get_by_genre(movies, genre)

print()
for movie in gmovies:
    print(movie)
    print()
