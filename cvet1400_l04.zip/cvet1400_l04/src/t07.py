"""
-------------------------------------------------------
T07
-------------------------------------------------------
Author:  Mila Cvetanovska
ID:      210311400
Email:   cvet1400@mylaurier.ca
Section: CP164 B
__updated__ = "2022-05-16"
-------------------------------------------------------
"""
# Imports

from utilities import list_test

source = [1, 2, 3, 4]

print(list_test(source))
