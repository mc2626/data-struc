"""
-------------------------------------------------------
T01
-------------------------------------------------------
Author:  Your Name
ID:      Your ID
Email:   your email@mylaurier.ca
__updated__ = "2022-06-17"
-------------------------------------------------------
"""
# Imports
from List_linked import List

print("-----------------------------------------------------")
print(f"def is_identical: ")
print()

target = List()
source = List()

lst1 = [11, 55, 22, 44, 66]
j = len(lst1) - 1
for i in lst1:
    source.insert(j, i)
j += 1
print(f"Source: ")
for i in source:
    print(i)
print()
lst2 = [11, 55, 22, 44, 33]
j = len(lst1) - 1
for i in lst2:
    target.insert(j, i)
j += 1
print(f"Target: ")
for i in target:
    print(i)
print()
b = source.is_identical_r(target)
print(f"Are both lists identical? : {b}")
print()
