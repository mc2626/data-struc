"""
-------------------------------------------------------
T05
-------------------------------------------------------
Author:  Mila Cvetanovska
ID:      210311400
Email:   cvet1400@mylaurier.ca
Section: CP164 B
__updated__ = "2022-05-02"
-------------------------------------------------------
"""
from Movie_utilities import read_movies
from utilities import stack_test

fv = open('movies.txt', 'r')
source = read_movies(fv)
fv.close()

stack_test(source)
