"""
-------------------------------------------------------
T02
-------------------------------------------------------
Author:  Your Name
ID:      Your ID
Email:   your email@mylaurier.ca
__updated__ = "2022-07-06"
-------------------------------------------------------
"""
# Imports
from test_Sorts_List_linked import SORTS, test_sort

test_sort(SORTS[0][0], SORTS[0][1])  # - bubble sort
print()
test_sort(SORTS[1][0], SORTS[1][1])  # - insertion sort
print()
test_sort(SORTS[4][0], SORTS[1][1])  # - selection sort
