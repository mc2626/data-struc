"""
-------------------------------------------------------
T05
-------------------------------------------------------
Author:  Your Name
ID:      Your ID
Email:   your email@mylaurier.ca
__updated__ = "2022-06-20"
-------------------------------------------------------
"""

# Imports
from List_linked import List

print("-----------------------------------------------------")
print(f"def union: ")
print()
target = List()
source1 = List()
source2 = List()

# test with: [], [1, 2, 3, 4], [1, 1, 1, 1], [1, 2, 3, 4, 5]
lst1 = [11, 22, 33, 44, 55]
j = len(lst1) - 1
for i in lst1:
    source1.insert(j, i)
j += 1
print(f"Source1: ")
for i in source1:
    print(i)
print()

# test with: [], [1, 2, 3, 4], [1, 1, 1, 1], [6, 7, 8, 9, 10]
lst2 = [44, 66, 77, 88]

k = len(lst2) - 1
for i in lst2:
    source2.insert(k, i)
k += 1
print(f"Source2: ")
for i in source2:
    print(i)
print()
target.union_r(source1, source2)
print()
print(f"Target Union: ")
for i in target:
    print(i)
print()
