"""
-------------------------------------------------------
Stack functions
-------------------------------------------------------
Author:  Mila Cvetanovska
ID:      210311400
Email:   cvet1400@mylaurier.ca
Section: CP164 B
__updated__ = "2022-05-14"
-------------------------------------------------------
"""
from Stack_array import Stack

import operator


def stack_split_alt(source):
    """
    -------------------------------------------------------
    Splits the source stack into separate target stacks.
    When finished source stack is empty. Values are
    pushed alternately onto the returned target stacks.
    Use: target1, target2 = stack_split_alt(source)
    -------------------------------------------------------
    Parameters:
        source - the stack to split into two parts (Stack)
    Returns:
        target1 - contains alternating values from source (Stack)
        target2 - contains other alternating values from source (Stack)
    -------------------------------------------------------
    """
    target1 = Stack()
    target2 = Stack()

    alt = True
    while not source.is_empty():
        if alt:
            target1.push(source.pop())
            alt = False
        else:
            target2.push(source.pop())
            alt = True
    return target1, target2


def stack_reverse(source):
    """
    -------------------------------------------------------
    Reverses the contents of a stack.
    Use: stack_reverse(source)
    -------------------------------------------------------
    Parameters:
        source - a Stack (Stack)
    Returns:
        None
    -------------------------------------------------------
    """
    temp1 = Stack()
    temp2 = Stack()

    if not source.is_empty():
        while not source.is_empty():
            temp1.push(source.pop())
        while not temp1.is_empty():
            temp2.push(temp1.pop())
        while not temp2.is_empty():
            source.push(temp2.pop())

    return None

    # # or
    # temp = []
    #
    # while not source.is_empty():
    #     temp.append(source.pop())
    #
    # while len(temp) > 0:
    #     source.push(temp.pop(0))
    # return


def postfix(string):
    """
    -------------------------------------------------------
    Evaluates a postfix expression.
    Use: answer = postfix(string)
    -------------------------------------------------------
    Parameters:
        string - the postfix string to evaluate (str)
    Returns:
        answer - the result of evaluating string (float)
    -------------------------------------------------------
    """

    # Constants
    OPERATORS = "+-*/"

    ops = {OPERATORS[0]: operator.add, OPERATORS[1]: operator.sub,
           OPERATORS[2]: operator.mul, OPERATORS[3]: operator.truediv}

    values = Stack()
    answer = 0.0

    string_list = string.split(" ")

    if len(string) > 0:
        for char in string_list:
            # isdigit() check only integers
            # need it to check floats too!!
            if char not in OPERATORS:
                if char.isdigit() or float(char):
                    values.push(char)
            else:
                first_val = float(values.pop())
                second_val = float(values.pop())
                answer = ops[char](second_val, first_val)
                values.push(answer)
                # for i in range(len(OPERATORS)):
                #     if char == OPERATORS[i] and not values.is_empty():
                #         first_val = int(values.pop())
                #         second_val = int(values.pop())
                #         answer = ops[OPERATORS[i]](second_val, first_val)
                #         values.push(answer)
    answer = float(values.pop())

    return answer


def stack_maze(maze):
    """
    -------------------------------------------------------
    Solves a maze using Depth-First search.
    Use: path = stack_maze(maze)
    -------------------------------------------------------
    Parameters:
        maze - dictionary of points in a maze, where each point
            represents a corridor end or a branch. Dictionary
            keys are the name of the point followed by a list of
            branches, if any. First point is named 'Start', exit
            is named 'X' (dict)
    Returns:
        path - list of points visited before the exit is reached,
            None if there is no exit (list of str)
    -------------------------------------------------------
    """

    stack = Stack()
    path = []

    # pushing value 'Start' onto Stack()

    stack.push('Start')
    stop = False

    while stop is False and not stack.is_empty():
        value1 = stack.pop()
        if value1 != "Start":
            path.append(value1)

        value2 = maze[value1]

        if "X" in value2:
            stop = True
            path.append("X")
        else:
            for i in value2:
                stack.push(i)

    return path
