"""
-------------------------------------------------------
T04
-------------------------------------------------------
Author:  Mila Cvetanovska
ID:      210311400
Email:   cvet1400@mylaurier.ca
Section: CP164 B
__updated__ = "2022-05-02"
-------------------------------------------------------
"""

from utilities import stack_test

source = [1, 2, 3, 4, 5]
stack_test(source)
