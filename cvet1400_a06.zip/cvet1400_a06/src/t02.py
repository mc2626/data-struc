"""
-------------------------------------------------------
T02
-------------------------------------------------------
Author:  Your Name
ID:      Your ID
Email:   your email@mylaurier.ca
__updated__ = "2022-05-26"
-------------------------------------------------------
"""
# Imports
from Priority_Queue_linked import Priority_Queue

queue = Priority_Queue()
SEP = "_" * 60

print(f"Queue (start): ")
print()
for i in queue:
    print(i)
queue.insert(1)
queue.insert(3)
queue.insert(2)
queue.insert(4)
print(f"Queue (inserting values): ")
for i in queue:
    print(i)
value1 = queue.remove()
value2 = queue.remove()
print(f"Queue (removing value(s)): {value1}, {value2}")
for i in queue:
    print(i)
value3 = queue.peek()
print(f"Queue (peek): {value3}")
for i in queue:
    print(i)

print(SEP)
print(f"def _move_front_to_rear")
print()
source = Priority_Queue()
target = Priority_Queue()
print(f"Source: ")
lst = [1, 2, 3, 4, 5]
for i in lst:
    source.insert(i)
for i in source:
    print(i)
print()
print(f"Target: ")
for j in target:
    print(j)
print()
target._move_front_to_rear(source)
print(f"Source: ")
for i in source:
    print(i)
print()
print(f"Target: ")
for j in target:
    print(j)

print(SEP)
print(f"def _append_queue")
print()
source = Priority_Queue()
target = Priority_Queue()
print(f"Source: ")
lst = [1, 2, 3, 4, 5]
for i in lst:
    source.insert(i)
for i in source:
    print(i)
print()
print(f"Target: ")
for j in target:
    print(j)
print()
target._append_queue(source)
print(f"Source: ")
for i in source:
    print(i)
print()
print(f"Target: ")
for j in target:
    print(j)

print(SEP)
print(f"def combine")
print()
source1 = Priority_Queue()
source2 = Priority_Queue()
target = Priority_Queue()
print(f"Source1: ")
lst1 = [1, 2, 3, 4, 5]
for i in lst1:
    source1.insert(i)
for i in source1:
    print(i)
print()
print(f"Source2: ")
lst2 = [6, 7, 8, 9, 10]
for i in lst2:
    source2.insert(i)
for i in source2:
    print(i)
print()
print(f"Target: []")
for j in target:
    print(j)
print()
target.combine(source1, source2)
print(f"Source1: []")
for i in source1:
    print(i)
print()
print(f"Source2: []")
for i in source2:
    print(i)
print()
print(f"Target: ")
for j in target:
    print(j)

print(SEP)
print(f"def split_alt")  # - questionable
print()
source = Priority_Queue()
target1 = Priority_Queue()
target2 = Priority_Queue()
print(f"Source: ")
lst = [1, 2, 3, 4, 5]
for i in lst:
    source.insert(i)
for i in source:
    print(i)
print()
print(f"Target1: []")
for j in target1:
    print(j)
print()
print(f"Target2: []")
for j in target2:
    print(j)
print()
target1, target2 = source.split_alt()
print(f"Source: []")
for i in source:
    print(i)
print()
print(f"Target1: ")
for j in target1:
    print(j)
print()
print(f"Target2: ")
for j in target2:
    print(j)
print()

print(SEP)
print(f"def split_key")  # - questionable
print()
source = Priority_Queue()
target1 = Priority_Queue()
target2 = Priority_Queue()
key = 3
print(f"Source: ")
lst = [1, 2, 3, 4, 5]
for i in lst:
    source.insert(i)
for i in source:
    print(i)
print()
print(f"Target1: []")
for j in target1:
    print(j)
print()
print(f"Target2: []")
for j in target2:
    print(j)
print()
target1, target2 = source.split_key(key)
print(f"Source: []")
for i in source:
    print(i)
print()
print(f"Target1: ")
for j in target1:
    print(j)
print()
print(f"Target2: ")
for j in target2:
    print(j)
