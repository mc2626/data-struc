"""
-------------------------------------------------------
T02
-------------------------------------------------------
Author:  Mila Cvetanovska
ID:      210311400
Email:   cvet1400@mylaurier.ca
Section: CP164 B
__updated__ = "2022-05-13"
-------------------------------------------------------
"""
from functions import file_analyze

fv = open("movies.txt", "r")
u, l, d, w, r = file_analyze(fv)

print(
    f"uppercase letters: {u}\nlowercase letters: {l}\ndigits: {d}\nwhite spaces: {w}\nremaining: {r}")
