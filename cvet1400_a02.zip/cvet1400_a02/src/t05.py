"""
-------------------------------------------------------
t05
-------------------------------------------------------
Author:  Mila Cvetanovska
ID:      210311400
Email:   cvet1400@mylaurier.ca
Section: CP164 B
__updated__ = "2022-05-06"
-------------------------------------------------------
"""
from Movie import Movie
from Movie_utilities import genre_counts, read_movies

fv = open('movies.txt', 'r')
movies = read_movies(fv)
fv.close

print(Movie.genres_menu())
print(f"Movies.GENRES: [0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10] ")
counts = genre_counts(movies)
print(f"counts list:   {counts}")
