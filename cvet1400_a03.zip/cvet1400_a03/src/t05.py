"""
-------------------------------------------------------
t05
-------------------------------------------------------
Author:  Mila Cvetanovska
ID:      210311400
Email:   cvet1400@mylaurier.ca
Section: CP164 B
__updated__ = "2022-05-14"
-------------------------------------------------------
"""
from functions import postfix

string = "4 5 + 12 * 2 3 * -"
# string = "12 5 -"
# string = "0 0 * 0 -"
# string = "2.5 3 *"
# string = '3 6 /'
# string = '1 2 -'
# string = '0'
answer = postfix(string)
print(f"Evaluate: {answer}")
