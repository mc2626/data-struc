"""
-------------------------------------------------------
T01
-------------------------------------------------------
Author:  Your Name
ID:      Your ID
Email:   your email@mylaurier.ca
__updated__ = "2022-06-30"
-------------------------------------------------------
"""
from BST_linked import BST
bst = BST()

# insertion

bst.insert(5)
bst.insert(8)
bst.insert(6)
bst.insert(3)
bst.insert(2)
print(f"Inserting into empty binary search tree: ")
for v in bst:
    print(v)
print()

# number of childern

count0 = bst.leaf_count()
print(f"Nodes with no childern: {count0}")

count1 = bst.one_child_count()
print(f"Nodes with one child: {count1}")

count2 = bst.two_child_count()
print(f"Nodes with two childern: {count2}\n")

#-------------------------------------------------

# nodes in order
a = bst.inorder()
print(f"Nodes in order: {a}")

#-------------------------------------------------

bst1 = BST()
bst2 = BST()

bst1.insert(6)
bst1.insert(8)

for v in bst1:
    print(v, end=', ')

bst2.insert(11)
bst2.insert(20)

print('\n')
for v in bst2:
    print(v, end=', ')

# is_identical

b = bst2.is_identical(bst1)
print(f"\n\nIs identical?: {b}")
