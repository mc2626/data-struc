"""
-------------------------------------------------------
T01
-------------------------------------------------------
Author:  Mila Cvetanovska
ID:      210311400
Email:   cvet1400@mylaurier.ca
Section: CP164 B
__updated__ = "2022-04-30"
-------------------------------------------------------
"""

from Movie import Movie

movie = Movie("Last Man On Earth, The", 1964,
              "Ubaldo Ragona", 6.9, [0])
string = movie.genres_string()
print(string)

# output
# science fiction
