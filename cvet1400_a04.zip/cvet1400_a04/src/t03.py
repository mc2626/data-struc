"""
-------------------------------------------------------
T03
-------------------------------------------------------
Author:  Your Name
ID:      Your ID
Email:   your email@mylaurier.ca
__updated__ = "2022-05-18"
-------------------------------------------------------
"""
# Imports
from Queue_array import Queue

source1 = Queue()
source2 = Queue()

target = Queue()
print(f"Target: {target._values}")

source1.insert(1)
source1.insert(2)
source1.insert(3)
source1.insert(4)
source1.insert(5)

print(f"Source 1: {source1._values}")

source2.insert(6)
source2.insert(7)
source2.insert(8)
source2.insert(9)
source2.insert(10)

print(f"Source 2: {source2._values}")
print()
target.combine(source1, source2)
print(f"Target: {target._values}")
print(f"Source 1: {source1._values}")
print(f"Source 1: {source1._values}")
