"""
-------------------------------------------------------
T01
-------------------------------------------------------
Author:  Your Name
ID:      Your ID
Email:   your email@mylaurier.ca
__updated__ = "2022-07-03"
-------------------------------------------------------
"""
# Imports
from functions import hash_table
from Movie_utilities import read_movies

fv = open('movies.txt', 'r')
movies = read_movies(fv)
fv.close

values = []
for movie in movies:
    values.append(movie)

slots = 7
hash_table(slots, values)
