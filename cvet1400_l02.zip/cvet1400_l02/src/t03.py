"""
-------------------------------------------------------
T03
-------------------------------------------------------
Author:  Mila Cvetanovska
ID:      210311400
Email:   cvet1400@mylaurier.ca
Section: CP164 B
__updated__ = "2022-05-02"
-------------------------------------------------------
"""
from Stack_array import Stack
from utilities import stack_to_array

stack = Stack()
target = []

stack.push(5)
stack.push(4)
stack.push(3)
stack.push(2)
stack.push(1)

print(f"Target array values: {target}")

print(f"Stack values: {stack._values}")
# for value in stack:
#     print(value)

print(f"\nStack_to_array func: ")

stack_to_array(stack, target)

print(f"\nTarget array values: {target}")

b = stack.is_empty()
print(f"Is Stack empty? {b}")
