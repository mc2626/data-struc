"""
-------------------------------------------------------
T02
-------------------------------------------------------
Author:  Your Name
ID:      Your ID
Email:   your email@mylaurier.ca
__updated__ = "2022-07-05"
-------------------------------------------------------
"""
# Imports
from Hash_Set_sorted import Hash_Set
from functions import insert_words, comparison_total

hs = Hash_Set(20)

file_variable = open("miserables.txt", "r")
insert_words(file_variable, hs)
file_variable.close()

hs.debug()
print()
print(f"Using array-based Sorted List Hash_Set")
print()
total, max_word = comparison_total(hs)
print(f"Total Comparisons: {total:,}")
print(f"Word with maximum comparisons: {max_word}")

# # number of "the" occurences
# file_variable = open("miserables.txt", "r")
# line = file_variable.readline()
# count = 0
# while line != "":
#     words = line.split(" ")
#     for i in words:
#         if i == "the":
#             count += 1
#     line = file_variable.readline()
#
# print(count)
