"""
-------------------------------------------------------
T06
-------------------------------------------------------
Author:  Mila Cvetanovska
ID:      210311400
Email:   cvet1400@mylaurier.ca
Section: CP164 B
__updated__ = "2022-05-09"
-------------------------------------------------------
"""
from Movie_utilities import read_movies
from Priority_Queue_array import Priority_Queue
from utilities import array_to_pq, pq_to_array, priority_queue_test

pq = Priority_Queue()

#-----------------------------------
# array_to_pq

source = [1, 2, 3, 4, 5]
print(f"Source: {source}")
print()
print(f"Priority Queue: {pq._values}")
array_to_pq(pq, source)
print()
print(f"Source: {source}")
print()
print(f"Priority Queue: {pq._values}")

#-----------------------------------
# pq_to_array

target = []

pq.insert(1)
pq.insert(2)
pq.insert(3)
pq.insert(4)
pq.insert(5)

print(f"Source: {target}")
print()
print(f"Priority Queue: {pq._values}")
pq_to_array(pq, target)
print()
print(f"Source: {target}")
print()
print(f"Priority Queue: {pq._values}")
print(f"Is Priority Queue Empty? {pq.is_empty()}")

#-----------------------------------
# priority_queue_test

a = [1, 2, 3, 4, 5, 0]

# fv = open('movies.txt', 'r')
# a = read_movies(fv)
# fv.close()


priority_queue_test(a)
