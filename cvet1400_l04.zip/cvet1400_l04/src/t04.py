"""
-------------------------------------------------------
T04
-------------------------------------------------------
Author:  Mila Cvetanovska
ID:      210311400
Email:   cvet1400@mylaurier.ca
Section: CP164 B
__updated__ = "2022-05-17"
-------------------------------------------------------
"""
# Imports
from List_array import List


source = List()

print(f"Source: {source._values}")
print()
source.prepend(99)
print(f"Source: {source._values}")
print()
source.prepend(1)
print(f"Source: {source._values}")
source.prepend(11)
source.prepend(55)
source.prepend(66)
print()
print(f"Source: {source._values}")
