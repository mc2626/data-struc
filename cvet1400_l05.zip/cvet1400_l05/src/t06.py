"""
-------------------------------------------------------
[program description]
-------------------------------------------------------
Author:  Your Name
ID:      Your ID
Email:   your email@mylaurier.ca
__updated__ = "2022-05-24"
-------------------------------------------------------
"""
# Imports
from functions import bag_to_set

bag = [4, 5, 3, 4, 5, 2, 2, 4]
new_set = bag_to_set(bag)
print(f"Bag: {bag}")
print(f"Set: {new_set}")
