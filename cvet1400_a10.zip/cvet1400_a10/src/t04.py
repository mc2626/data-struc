"""
-------------------------------------------------------
T04
-------------------------------------------------------
Author:  Your Name
ID:      Your ID
Email:   your email@mylaurier.ca
__updated__ = "2022-07-10"
-------------------------------------------------------
"""
# Imports
from Sorts_Deque_linked import Sorts
from Deque_linked import Deque

dq = Deque()
# a = [1346, 23, 456, 199986, 22, 0]
# a = [20, 15, 10, 9, 18, 4, 7, 0]
a = [100, 3, 0, 1000, 16, 10000, 20, 15, 10, 9,
     18, 4, 7, 0, 4000000]
for i in a:
    dq.insert_rear(i)
print(f"Unsorted: ")
for v in dq:
    print(v, end=" ")
print()
print()
Sorts.gnome_sort(dq)
print(f"Sorted: ")
for v in dq:
    print(v, end=" ")
print()
print(f"Is Sorted? {Sorts.sort_test(dq)}")
