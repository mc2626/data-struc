"""
-------------------------------------------------------
T02
-------------------------------------------------------
Author:  Your Name
ID:      Your ID
Email:   your email@mylaurier.ca
__updated__ = "2022-05-24"
-------------------------------------------------------
"""
# Imports
from functions import gcd

m = 30
n = 20
ans = gcd(m, n)
print(f"m: {m}")
print(f"n: {n}")
print(f"GCD: {ans}")
