"""
-------------------------------------------------------
T03
-------------------------------------------------------
Author:  Your Name
ID:      Your ID
Email:   your email@mylaurier.ca
__updated__ = "2022-06-23"
-------------------------------------------------------
"""
# Imports
from Deque_linked import Deque, _Deque_Node

deque = Deque()
SEP = "_" * 60

print(f"Deque (start): ")
print()
for i in deque:
    print(i)
deque.insert_front(1)
deque.insert_front(2)
deque.insert_front(3)
deque.insert_front(4)
print(f"Deque (insert_front): ")
for i in deque:
    print(i)
print()
deque.insert_rear(6)
deque.insert_rear(7)
deque.insert_rear(8)
print(f"Deque (insert_rear): ")
for i in deque:
    print(i)
print()
value1 = deque.remove_front()
value2 = deque.remove_front()
print(f"Deque (remove_front): {value1}, {value2}")
for i in deque:
    print(i)
print()
value3 = deque.remove_rear()
value4 = deque.remove_rear()
print(f"Deque (remove_rear): {value3}, {value4}")
for i in deque:
    print(i)
print()
value5 = deque.peek_front()
value6 = deque.peek_rear()
print(f"Deque (peek_front): {value5}")
print(f"Deque (peek_rear): {value6}")
print()

# print(SEP)
# print(f"def _swap")
# print()
# source = Deque()
# print(f"Source: ")
# lst = [1, 2, 3, 4, 5]
# for i in lst:
#     source.insert_rear(i)
# for i in source:
#     print(i)
# print()
# l = _Deque_Node(2, 1, 3)
# r = _Deque_Node(4, 3, 5)
# source._swap(l, r)
# print(f"Source: ")
# for i in source:
#     print(i)
